import SwiftUI

// MARK: - 6. الواجهة الرئيسية

struct ContentView: View {
    @StateObject var viewModel = WebViewModel()
    @StateObject var websitesManager = WebsitesManager()
    @State private var isToolbarHidden = true
    @State private var showWebsitesBar = false
    @State private var showTabsTray = false
    
    // متغير جديد لعرض السجل
    @State private var showHistory = false
    // متغيرات الكونسول والسكربتات
    @State private var showConsole = false
    @State private var showScripts = false
    
    var body: some View {
        ZStack(alignment: .top) {
            
            // 1. المتصفح (في الخلفية)
            ZStack(alignment: .trailing) {
                VStack(spacing: 0) {
                    if viewModel.isLoading {
                        ProgressView().progressViewStyle(LinearProgressViewStyle(tint: .blue)).frame(height: 2)
                    }
                    WebViewContainer(viewModel: viewModel)
                }
                .edgesIgnoringSafeArea(.bottom)
                .onAppear { viewModel.websitesManager = websitesManager }
                
                // شريط المواقع الجانبي
                if showWebsitesBar {
                    Color.black.opacity(0.01)
                        .edgesIgnoringSafeArea(.all)
                        .onTapGesture {
                            withAnimation(.spring()) { showWebsitesBar = false }
                        }
                        .zIndex(5)
                    
                    WebsitesSidebarView(viewModel: viewModel, showWebsitesBar: $showWebsitesBar)
                        .transition(.move(edge: .trailing))
                        .zIndex(6)
                }
            }
            // 🔥 هنا تم ربط وضع القراءة بشكل صحيح مع طبقة المتصفح
            .fullScreenCover(isPresented: $viewModel.showReaderMode) {
                ReaderModeView(isPresented: $viewModel.showReaderMode, title: viewModel.readerTitle, content: viewModel.readerContent)
            }
            
            // 🔥 واجهة السجل (History)
            if showHistory {
                HistoryView(viewModel: viewModel, historyManager: viewModel.historyManager, isVisible: $showHistory)
                    .transition(.opacity)
                    .zIndex(20)
            }
            
            // 🔥 واجهة الكونسول (Console)
            if showConsole {
                VStack {
                    Spacer()
                    ConsoleView(viewModel: viewModel, isVisible: $showConsole)
                }
                .transition(.move(edge: .bottom))
                .zIndex(25)
            }
            
            // 🔥 واجهة مدير السكربتات (صفحة كاملة الآن)
            if showScripts {
                ScriptManagerView(scriptManager: viewModel.scriptManager, viewModel: viewModel, isVisible: $showScripts)
                    .transition(.move(edge: .bottom))
                    .zIndex(30)
            }
            
            // شريط الأدوات السفلي العائم (Toolbar)
            VStack(spacing: 20) {
                Button(action: {
                    withAnimation(.spring()) {
                        showWebsitesBar.toggle()
                        if showWebsitesBar { isToolbarHidden = true }
                    }
                }) {
                    ZStack {
                        Image(systemName: "globe").font(.title3).foregroundColor(showWebsitesBar ? .blue : .primary)
                        if viewModel.adsBlocked > 0 {
                            Circle().fill(Color.red).frame(width: 8, height: 8).offset(x: 10, y: -10)
                        }
                    }
                }
                
                // زر وضع القراءة (الجديد)
                Button(action: {
                    viewModel.extractPageContent()
                }) {
                    Image(systemName: "doc.text.viewfinder")
                        .font(.system(size: 20))
                        .foregroundColor(.primary)
                        .padding(8)
                }
                
                // زر السجل
                Button(action: {
                    withAnimation(.spring()) {
                        showHistory = true
                        isToolbarHidden = true
                    }
                }) {
                    Image(systemName: "clock.arrow.circlepath")
                        .font(.title3)
                        .foregroundColor(.primary)
                }
                
                // 🔥 زر الكونسول
                Button(action: {
                    withAnimation(.spring()) {
                        showConsole.toggle()
                        isToolbarHidden = true
                    }
                }) {
                    Image(systemName: "terminal")
                        .font(.title3)
                        .foregroundColor(.orange)
                }
                
                // 🔥 زر السكربتات
                Button(action: {
                    withAnimation(.spring()) {
                        showScripts = true
                        isToolbarHidden = true
                    }
                }) {
                    Image(systemName: "curlybraces")
                        .font(.title3)
                        .foregroundColor(.green)
                }
                
                Divider().frame(width: 30).background(Color.gray.opacity(0.3))
                
                Button(action: { viewModel.toggleForcedDarkMode() }) {
                    Image(systemName: "moon.stars.fill")
                        .font(.headline)
                        .foregroundColor(viewModel.isForcedDarkMode ? .yellow : .primary)
                }
                
                Button(action: { viewModel.reload() }) { Image(systemName: "arrow.clockwise").font(.headline) }
                Button(action: { viewModel.addNewTab() }) { Image(systemName: "plus").font(.title3).foregroundColor(.blue) }
                Button(action: { viewModel.goBack() }) { Image(systemName: "chevron.backward").font(.headline) }.disabled(!viewModel.canGoBack)
                Button(action: { viewModel.goForward() }) { Image(systemName: "chevron.forward").font(.headline) }.disabled(!viewModel.canGoForward)
            }
            .padding(15)
            .background(.ultraThinMaterial)
            .cornerRadius(20, corners: [.topLeft, .bottomLeft])
            .shadow(radius: 5)
            .offset(x: isToolbarHidden ? 80 : 0)
            .gesture(DragGesture().onChanged { if $0.translation.width > 5 { withAnimation { isToolbarHidden = true } } })
            .zIndex(4)
            .frame(maxWidth: .infinity, alignment: .trailing) // محاذاة لليمين
            .frame(maxHeight: .infinity, alignment: .bottom) // محاذاة للأسفل
            
            if isToolbarHidden {
                Color.clear.frame(width: 25).contentShape(Rectangle())
                    .gesture(DragGesture().onChanged { if $0.translation.width < -10 { withAnimation { isToolbarHidden = false } } })
                    .zIndex(10)
                    .frame(maxWidth: .infinity, alignment: .trailing)
            }
            
            
            // 2. منطقة استشعار السحب العلوية
            if !showTabsTray {
                Color.clear
                    .frame(height: 30)
                    .contentShape(Rectangle())
                    .ignoresSafeArea()
                    .zIndex(20)
                    .gesture(
                        DragGesture(minimumDistance: 20, coordinateSpace: .global)
                            .onEnded { value in
                                if value.translation.height > 50 && value.startLocation.y < 100 {
                                    withAnimation(.spring(response: 0.5, dampingFraction: 0.7)) {
                                        showTabsTray = true
                                    }
                                }
                            }
                    )
            }
            
            // 3. شريط التبويبات
            if showTabsTray {
                ZStack(alignment: .top) {
                    Color.black.opacity(0.3)
                        .ignoresSafeArea()
                        .onTapGesture {
                            withAnimation { showTabsTray = false }
                        }
                    
                    TabsTrayView(viewModel: viewModel, isVisible: $showTabsTray)
                        .transition(.move(edge: .top))
                }
                .zIndex(30)
            }
        }
    }
}

// MARK: - Helpers

extension View {
    func cornerRadius(_ radius: CGFloat, corners: UIRectCorner) -> some View {
        clipShape(RoundedCorner(radius: radius, corners: corners))
    }
}

struct RoundedCorner: Shape {
    var radius: CGFloat = .infinity
    var corners: UIRectCorner = .allCorners
    func path(in rect: CGRect) -> Path {
        let path = UIBezierPath(roundedRect: rect, byRoundingCorners: corners, cornerRadii: CGSize(width: radius, height: radius))
        return Path(path.cgPath)
    }
}

extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 3: (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6: (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8: (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default: (a, r, g, b) = (1, 1, 1, 0)
        }
        self.init(.sRGB, red: Double(r) / 255, green: Double(g) / 255, blue: Double(b) / 255, opacity: Double(a) / 255)
    }
}
