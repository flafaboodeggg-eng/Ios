import SwiftUI
import WebKit

struct WebView: UIViewRepresentable {
    let url: URL
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    func makeUIView(context: Context) -> WKWebView {
        let prefs = WKWebpagePreferences()
        prefs.allowsContentJavaScript = true
        
        let config = WKWebViewConfiguration()
        config.defaultWebpagePreferences = prefs
        config.allowsInlineMediaPlayback = true
        
        // تفعيل تخزين الكوكيز والجلسات
        config.websiteDataStore = WKWebsiteDataStore.default()
        
        // --- حقن كود لتعديل حجم الشاشة (85%) ومنع التكبير (Zoom) ---
        // هذا السكريبت يفرض إعدادات العرض (Viewport) بمجرد تحميل الصفحة
        let viewportScriptString = """
            var meta = document.createElement('meta');
            meta.name = 'viewport';
            meta.content = 'width=device-width, initial-scale=0.85, maximum-scale=0.70, user-scalable=no';
            var head = document.getElementsByTagName('head')[0];
            head.appendChild(meta);
        """
        let viewportScript = WKUserScript(source: viewportScriptString, injectionTime: .atDocumentEnd, forMainFrameOnly: true)
        config.userContentController.addUserScript(viewportScript)
        // -----------------------------------------------------------
        
        let webView = WKWebView(frame: .zero, configuration: config)
        
        // استخدام User Agent مطابق للآيفون
        webView.customUserAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1"
        
        webView.allowsBackForwardNavigationGestures = true
        webView.navigationDelegate = context.coordinator
        webView.uiDelegate = context.coordinator
        
        // --- منع التكبير والتصغير من خلال ScrollView أيضاً ---
        webView.scrollView.minimumZoomScale = 1.0
        webView.scrollView.maximumZoomScale = 1.0
        webView.scrollView.isScrollEnabled = true
        webView.scrollView.bounces = false // إلغاء الارتداد لجعلها تشبه التطبيق أكثر (اختياري)
        // ---------------------------------------------------
        
        return webView
    }
    
    func updateUIView(_ webView: WKWebView, context: Context) {
        if webView.url == nil {
            let request = URLRequest(url: url)
            webView.load(request)
        }
    }
    
    class Coordinator: NSObject, WKNavigationDelegate, WKUIDelegate {
        var parent: WebView
        
        init(_ parent: WebView) {
            self.parent = parent
        }
        
        // 1. إدارة النوافذ المنبثقة
        func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
            if let url = navigationAction.request.url {
                webView.load(navigationAction.request)
            }
            return nil
        }
        
        // 2. فلترة الروابط واتخاذ القرار
        func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
            guard let url = navigationAction.request.url else {
                decisionHandler(.cancel)
                return
            }
            
            let urlString = url.absoluteString
            let host = url.host ?? ""
            
            // السماح بجميع الروابط الخدمية
            if url.scheme == "about" || url.scheme == "blob" || url.scheme == "data" {
                decisionHandler(.allow)
                return
            }
            
            // السماح بنطاقات جوجل وجيمني
            if host.contains("google.com") ||
                host.contains("gstatic.com") ||
                host.contains("googleapis.com") ||
                host.contains("googleusercontent.com") ||
                host.contains("gemini.google.com") ||
                urlString.contains("signin") {
                
                decisionHandler(.allow)
                return
            }
            
            print("تم حظر الرابط الخارجي: \(url.absoluteString)")
            decisionHandler(.cancel)
        }
    }
}

struct ContentView: View {
    var body: some View {
        WebView(url: URL(string: "https://gemini.google.com")!)
            .edgesIgnoringSafeArea(.all)
    }
}
