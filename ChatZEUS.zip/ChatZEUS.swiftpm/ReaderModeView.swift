import SwiftUI

struct ReaderModeView: View {
    @Binding var isPresented: Bool
    let title: String
    let content: String
    
    // إعدادات العرض
    @State private var fontSize: CGFloat = 20
    @State private var showSettings = false
    
    var body: some View {
        ZStack(alignment: .top) {
            // خلفية داكنة للقراءة المركزة
            Color(hex: "1C1C1E").edgesIgnoringSafeArea(.all)
            
            VStack(spacing: 0) {
                // 1. الشريط العلوي
                HStack {
                    // زر إعدادات الخط (يسار)
                    Button(action: {
                        withAnimation { showSettings.toggle() }
                    }) {
                        Image(systemName: "textformat.size")
                            .font(.system(size: 18, weight: .regular))
                            .foregroundColor(.white)
                            .padding(10)
                            .background(Color.gray.opacity(0.3))
                            .clipShape(Circle())
                    }
                    
                    Spacer()
                    
                    // عنوان الصفحة (وسط)
                    Text(title)
                        .font(.system(size: 16, weight: .semibold))
                        .foregroundColor(.white)
                        .lineLimit(1)
                        .padding(.horizontal)
                    
                    Spacer()
                    
                    // زر الإغلاق (يمين)
                    Button(action: {
                        isPresented = false
                    }) {
                        Image(systemName: "xmark")
                            .font(.system(size: 16, weight: .bold))
                            .foregroundColor(.white)
                            .padding(10)
                            .background(Color.gray.opacity(0.3))
                            .clipShape(Circle())
                    }
                }
                .padding(.horizontal)
                .padding(.top, 10) // مساحة للـ Safe Area
                .padding(.bottom, 15)
                .background(Color(hex: "1C1C1E"))
                .zIndex(2)
                
                // قائمة إعدادات الخط المنبثقة
                if showSettings {
                    HStack(spacing: 20) {
                        Button(action: { if fontSize > 14 { fontSize -= 2 } }) {
                            Image(systemName: "minus")
                                .foregroundColor(.white)
                                .frame(width: 40, height: 40)
                                .background(Color.gray.opacity(0.4))
                                .cornerRadius(8)
                        }
                        
                        Text("\(Int(fontSize))")
                            .foregroundColor(.white)
                            .font(.headline)
                        
                        Button(action: { if fontSize < 36 { fontSize += 2 } }) {
                            Image(systemName: "plus")
                                .foregroundColor(.white)
                                .frame(width: 40, height: 40)
                                .background(Color.gray.opacity(0.4))
                                .cornerRadius(8)
                        }
                    }
                    .padding()
                    .background(Color(hex: "2C2C2E"))
                    .cornerRadius(12)
                    .padding(.bottom, 10)
                    .transition(.scale.combined(with: .opacity))
                }
                
                // 2. منطقة النص (Scroll View)
                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        // عنوان الفصل الكبير
                        Text(title)
                            .font(.system(size: fontSize + 6, weight: .bold, design: .serif))
                            .foregroundColor(.white)
                            .multilineTextAlignment(.center)
                            .frame(maxWidth: .infinity)
                            .padding(.bottom, 10)
                        
                        // نص الفصل
                        Text(content)
                            .font(.system(size: fontSize, weight: .regular, design: .serif))
                            .foregroundColor(Color(hex: "E5E5E7")) // لون أبيض مائل للرمادي قليلاً لراحة العين
                            .lineSpacing(8)
                            .multilineTextAlignment(.leading)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    .padding(.horizontal, 20)
                    .padding(.bottom, 50)
                }
            }
        }
        .statusBar(hidden: true) // إخفاء شريط الحالة لتركيز كامل
    }
}
