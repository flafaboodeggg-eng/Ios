import Foundation
import SwiftUI
import WebKit

// MARK: - 3. هيكلية التبويبات

struct SavedTabInfo: Codable {
    let id: UUID
    let title: String
    let url: String
}

struct TabItem: Identifiable {
    let id: UUID
    var title: String
    var url: String
    var webView: WKWebView
    
    init(id: UUID = UUID(), title: String, url: String, webView: WKWebView) {
        self.id = id
        self.title = title
        self.url = url
        self.webView = webView
    }
}

// هيكل سجل الكونسول (تمت إضافته لحل الخطأ)
struct ConsoleLog: Identifiable {
    let id = UUID()
    let type: String
    let message: String
}

class WebViewModel: ObservableObject {
    @Published var tabs: [TabItem] = []
    @Published var currentTabID: UUID
    
    @Published var isLoading: Bool = false
    @Published var canGoBack: Bool = false
    @Published var canGoForward: Bool = false
    @Published var currentURL: String = ""
    @Published var adsBlocked: Int = 0
    
    @Published var isForcedDarkMode: Bool = false
    
    // MARK: - Reader Mode Variables (متغيرات وضع القراءة)
    @Published var showReaderMode: Bool = false
    @Published var readerContent: String = ""
    @Published var readerTitle: String = ""
    
    @Published var consoleLogs: [ConsoleLog] = []
    
    var websitesManager: WebsitesManager?
    // تأكد من وجود ملفات لهذه الكلاسات، وإلا سيظهر خطأ
    var historyManager: HistoryManager = HistoryManager()
    var scriptManager: ScriptManager = ScriptManager()
    
    private let savedTabsKey = "browser_saved_tabs_list"
    private let lastActiveTabKey = "browser_last_active_tab_id"
    private let forcedDarkModeKey = "browser_forced_dark_mode_key"
    
    init() {
        self.isForcedDarkMode = UserDefaults.standard.bool(forKey: forcedDarkModeKey)
        scriptManager.loadScripts()
        
        // إعداد قيمة افتراضية للـ ID لتجنب أخطاء التهيئة
        self.currentTabID = UUID()
        
        if let data = UserDefaults.standard.data(forKey: "browser_saved_tabs_list"),
           let savedTabsInfo = try? JSONDecoder().decode([SavedTabInfo].self, from: data),
           !savedTabsInfo.isEmpty {
            
            var restoredTabs: [TabItem] = []
            // نقوم بتوليد كود الحقن مرة واحدة
            let injectionCode = ScriptManager().generateInjectionCode()
            
            for info in savedTabsInfo {
                let webView = WebViewModel.createConfiguredWebView(scripts: injectionCode)
                if let url = URL(string: info.url) {
                    webView.load(URLRequest(url: url))
                }
                let tab = TabItem(id: info.id, title: info.title, url: info.url, webView: webView)
                restoredTabs.append(tab)
            }
            
            self.tabs = restoredTabs
            
            if let lastIDString = UserDefaults.standard.string(forKey: "browser_last_active_tab_id"),
               let lastID = UUID(uuidString: lastIDString),
               restoredTabs.contains(where: { $0.id == lastID }) {
                self.currentTabID = lastID
            } else {
                self.currentTabID = restoredTabs.first!.id
            }
            
        } else {
            let initialWebView = WebViewModel.createConfiguredWebView(scripts: ScriptManager().generateInjectionCode())
            let initialTab = TabItem(title: "البداية", url: "https://google.com/", webView: initialWebView)
            
            self.tabs = [initialTab]
            self.currentTabID = initialTab.id
            
            if let url = URL(string: initialTab.url) {
                initialWebView.load(URLRequest(url: url))
            }
        }
    }
    
    // MARK: - Reader Mode Logic (منطق وضع القراءة)
    func extractPageContent() {
        guard let webView = currentWebView else { return }
        
        let script = """
        (function() {
            var title = document.title;
            var content = "";
            
            // 1. محاولة العثور على المقال الرئيسي
            var article = document.querySelector('article');
            if (article) {
                content = article.innerText;
            } else {
                // 2. محاولة تجميع الفقرات (الأكثر شيوعاً في فصول الروايات)
                var ps = document.querySelectorAll('p, h1, h2, h3, h4, h5, h6, div.text, div.content');
                
                // نقوم بجمع النص حتى لو كان قليلاً، لا حاجة لشرط الطول الكبير
                for (var i=0; i<ps.length; i++) {
                    // تجاهل العناصر المخفية
                    if (ps[i].innerText.length > 0 && ps[i].style.display !== 'none') {
                         content += ps[i].innerText + "\\n\\n";
                    }
                }
                
                // 3. الملاذ الأخير: إذا كان المحتوى فارغاً، نسحب نص الجسم بالكامل
                if (content.length < 50) {
                     content = document.body.innerText;
                }
            }
            return JSON.stringify({ "title": title, "content": content });
        })();
        """
        
        webView.evaluateJavaScript(script) { [weak self] (result, error) in
            guard let self = self else { return }
            
            if let jsonString = result as? String,
               let data = jsonString.data(using: .utf8),
               let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: String] {
                
                DispatchQueue.main.async {
                    self.readerTitle = json["title"] ?? "بدون عنوان"
                    // تنظيف النص
                    self.readerContent = json["content"]?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
                    
                    if !self.readerContent.isEmpty {
                        self.showReaderMode = true
                    }
                }
            }
        }
    }
    
    func toggleForcedDarkMode() {
        isForcedDarkMode.toggle()
        UserDefaults.standard.set(isForcedDarkMode, forKey: forcedDarkModeKey)
        applyDarkMode(to: currentWebView)
    }
    
    func applyDarkMode(to webView: WKWebView?) {
        let js: String
        if isForcedDarkMode {
            js = """
            if (!document.getElementById('forced-dark-mode-style')) {
                var style = document.createElement('style');
                style.id = 'forced-dark-mode-style';
                style.innerHTML = 'html { filter: invert(100%) hue-rotate(180deg) !important; } img, video, iframe, canvas, svg, :not(object):not(body)>embed, object { filter: invert(100%) hue-rotate(180deg) !important; }';
                document.head.appendChild(style);
            }
            """
        } else {
            js = """
            if (document.getElementById('forced-dark-mode-style')) {
                document.getElementById('forced-dark-mode-style').remove();
            }
            """
        }
        webView?.evaluateJavaScript(js)
    }
    
    func saveTabsState() {
        let savedData = tabs.map { SavedTabInfo(id: $0.id, title: $0.title, url: $0.url) }
        if let encoded = try? JSONEncoder().encode(savedData) {
            UserDefaults.standard.set(encoded, forKey: savedTabsKey)
        }
        UserDefaults.standard.set(currentTabID.uuidString, forKey: lastActiveTabKey)
    }
    
    func executeJS(_ js: String) {
        currentWebView?.evaluateJavaScript(js) { result, error in
            if let error = error {
                self.addConsoleLog(type: "error", message: error.localizedDescription)
            } else if let result = result {
                self.addConsoleLog(type: "log", message: "Result: \(result)")
            } else {
                self.addConsoleLog(type: "log", message: "Executed")
            }
        }
    }
    
    func addConsoleLog(type: String, message: String) {
        let log = ConsoleLog(type: type, message: message)
        DispatchQueue.main.async {
            self.consoleLogs.append(log)
            if self.consoleLogs.count > 200 {
                self.consoleLogs.removeFirst()
            }
        }
    }
    
    func clearConsole() {
        consoleLogs.removeAll()
    }
    
    func reloadScriptsInCurrentTab() {
        let code = scriptManager.generateInjectionCode()
        currentWebView?.evaluateJavaScript(code)
    }
    
    // دالة إنشاء الويب فيو
    static func createConfiguredWebView(scripts: String = "") -> WKWebView {
        let prefs = WKWebpagePreferences()
        prefs.allowsContentJavaScript = true
        
        let config = WKWebViewConfiguration()
        config.defaultWebpagePreferences = prefs
        config.allowsInlineMediaPlayback = true
        config.mediaTypesRequiringUserActionForPlayback = []
        
        // --- قسم مانع الإعلانات ---
        // ملاحظة: إذا كان AdBlockManager غير موجود، يرجى التأكد من إنشاء الملف الخاص به.
        // هنا نستخدم singleton افتراضي إذا كان متوفراً في مشروعك.
        // إذا كان اسم الكلاس عندك مختلف (مثلاً SmartEngine)، عدله هنا.
        
        /*
         // تفعيل مانع الإعلانات إذا كان الكلاس موجوداً
         let rules = AdBlockManager.shared.createContentBlockerRules()
         WKContentRuleListStore.default().compileContentRuleList(
         forIdentifier: "SmartBlockList",
         encodedContentRuleList: rules
         ) { list, error in
         if let list = list {
         DispatchQueue.main.async {
         config.userContentController.add(list)
         }
         }
         }
         
         let scriptSource = AdBlockManager.shared.getSmartInjectionScript()
         let script = WKUserScript(source: scriptSource, injectionTime: .atDocumentStart, forMainFrameOnly: false)
         config.userContentController.addUserScript(script)
         
         let consoleBridge = AdBlockManager.shared.getConsoleBridgeScript()
         let consoleScript = WKUserScript(source: consoleBridge, injectionTime: .atDocumentStart, forMainFrameOnly: false)
         config.userContentController.addUserScript(consoleScript)
         */
        
        if !scripts.isEmpty {
            let userScriptObj = WKUserScript(source: scripts, injectionTime: .atDocumentEnd, forMainFrameOnly: false)
            config.userContentController.addUserScript(userScriptObj)
        }
        
        let viewportScript = WKUserScript(
            source: "var meta = document.createElement('meta'); meta.name = 'viewport'; meta.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no'; document.getElementsByTagName('head')[0].appendChild(meta);",
            injectionTime: .atDocumentEnd,
            forMainFrameOnly: true
        )
        config.userContentController.addUserScript(viewportScript)
        
        let webView = WKWebView(frame: .zero, configuration: config)
        webView.customUserAgent = "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1"
        webView.allowsBackForwardNavigationGestures = true
        
        webView.scrollView.showsVerticalScrollIndicator = false
        webView.scrollView.showsHorizontalScrollIndicator = false
        
        return webView
    }
    
    var currentWebView: WKWebView? {
        tabs.first(where: { $0.id == currentTabID })?.webView
    }
    
    func addNewTab(url: URL? = nil) {
        let newWebView = WebViewModel.createConfiguredWebView(scripts: scriptManager.generateInjectionCode())
        let startURL = url ?? URL(string: "https://www.google.com")!
        newWebView.load(URLRequest(url: startURL))
        
        let newTab = TabItem(title: "تبويب جديد", url: startURL.absoluteString, webView: newWebView)
        tabs.append(newTab)
        currentTabID = newTab.id
        saveTabsState()
    }
    
    func closeTab(_ id: UUID) {
        guard tabs.count > 1 else { return }
        
        if let index = tabs.firstIndex(where: { $0.id == id }) {
            if currentTabID == id {
                let newIndex = index == 0 ? 1 : index - 1
                currentTabID = tabs[newIndex].id
            }
            tabs.remove(at: index)
            saveTabsState()
        }
    }
    
    func selectTab(_ id: UUID) {
        currentTabID = id
        updateStateFromCurrentTab()
        saveTabsState()
        applyDarkMode(to: currentWebView)
        clearConsole()
    }
    
    func updateStateFromCurrentTab() {
        guard let webView = currentWebView else { return }
        self.currentURL = webView.url?.absoluteString ?? ""
        self.canGoBack = webView.canGoBack
        self.canGoForward = webView.canGoForward
        self.isLoading = webView.isLoading
    }
    
    func goBack() { currentWebView?.goBack() }
    func goForward() { currentWebView?.goForward() }
    func reload() { currentWebView?.reload() }
    func loadUrl(url: URL) {
        currentWebView?.load(URLRequest(url: url))
        websitesManager?.saveLastURL(url.absoluteString)
    }
}
