import SwiftUI
import Kingfisher

// MARK: - 5. واجهات المستخدم (UI)

struct TabsTrayView: View {
    @ObservedObject var viewModel: WebViewModel
    @Binding var isVisible: Bool
    @State private var tabToFavorite: TabItem?
    
    var body: some View {
        VStack(spacing: 0) {
            // مقبض السحب
            Capsule()
                .fill(Color.gray.opacity(0.5))
                .frame(width: 40, height: 5)
                .padding(.top, 10)
                .padding(.bottom, 20)
            
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 15) {
                    // قائمة التبويبات
                    ForEach(viewModel.tabs) { tab in
                        TabCardView(
                            tab: tab,
                            isSelected: viewModel.currentTabID == tab.id,
                            action: { selectTab(tab) },
                            closeAction: { closeTab(tab) },
                            favoriteAction: { self.tabToFavorite = tab }
                        )
                    }
                    
                    // زر إضافة تبويب جديد
                    addTabButton
                }
                .padding(.horizontal, 20)
            }
            .frame(height: 200)
            
            Spacer()
        }
        .background(.ultraThinMaterial)
        .cornerRadius(30, corners: [.bottomLeft, .bottomRight])
        .shadow(color: .black.opacity(0.3), radius: 20, x: 0, y: 10)
        .frame(height: 300)
        .sheet(item: $tabToFavorite) { tab in
            if let manager = viewModel.websitesManager {
                AddWebsiteView(websitesManager: manager, name: tab.title, url: tab.url)
            }
        }
    }
    
    // MARK: - Subviews & Actions
    
    private var addTabButton: some View {
        Button(action: {
            viewModel.addNewTab()
            withAnimation(.spring()) { isVisible = false }
        }) {
            VStack {
                Image(systemName: "plus")
                    .font(.system(size: 30))
                    .foregroundColor(.white.opacity(0.8))
            }
            .frame(width: 140, height: 180)
            .background(Color.white.opacity(0.1))
            .cornerRadius(15)
            .overlay(
                RoundedRectangle(cornerRadius: 15)
                    .stroke(style: StrokeStyle(lineWidth: 2, dash: [5]))
                    .foregroundColor(.white.opacity(0.3))
            )
        }
    }
    
    private func selectTab(_ tab: TabItem) {
        viewModel.selectTab(tab.id)
        withAnimation(.spring()) { isVisible = false }
    }
    
    private func closeTab(_ tab: TabItem) {
        withAnimation { viewModel.closeTab(tab.id) }
    }
}

struct TabCardView: View {
    let tab: TabItem
    let isSelected: Bool
    let action: () -> Void
    let closeAction: () -> Void
    let favoriteAction: () -> Void
    
    // استخراج الألوان لتبسيط التعبيرات في الـ Body
    private var cardBackground: Color {
        isSelected ? Color.white : Color.black.opacity(0.3)
    }
    
    private var textColor: Color {
        isSelected ? .black : .white
    }
    
    private var borderColor: Color {
        isSelected ? Color.blue : Color.white.opacity(0.2)
    }
    
    var body: some View {
        ZStack(alignment: .topTrailing) {
            Button(action: action) {
                VStack(spacing: 10) {
                    // أيقونة الموقع
                    KFImage(URL(string: "https://www.google.com/s2/favicons?domain=\(tab.url)&sz=128"))
                        .placeholder {
                            Circle().fill(Color.gray.opacity(0.3))
                        }
                        .resizable()
                        .frame(width: 40, height: 40)
                        .clipShape(Circle())
                        .shadow(radius: 5)
                    
                    Text(tab.title)
                        .font(.caption)
                        .bold()
                        .foregroundColor(textColor)
                        .lineLimit(2)
                        .multilineTextAlignment(.center)
                        .padding(.horizontal, 5)
                }
                .frame(width: 140, height: 180)
                .background(cardBackground)
                .cornerRadius(15)
                .overlay(
                    RoundedRectangle(cornerRadius: 15)
                        .stroke(borderColor, lineWidth: 2)
                )
            }
            .contextMenu {
                Button(action: favoriteAction) {
                    Label("إضافة للمفضلة", systemImage: "star.fill")
                }
            }
            
            // زر الإغلاق
            Button(action: closeAction) {
                Image(systemName: "xmark.circle.fill")
                    .foregroundColor(isSelected ? .gray : .white)
                    .padding(8)
            }
        }
        .scaleEffect(isSelected ? 1.05 : 1.0)
        .animation(.spring(), value: isSelected)
    }
}

// MARK: - NEW: واجهة سجل التاريخ (History UI)

struct HistorySectionHeader: View {
    let title: String
    
    var body: some View {
        Text(title)
            .font(.headline)
            .foregroundColor(.white)
            .padding(.horizontal)
            .padding(.vertical, 8)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.blue.opacity(0.2))
            .cornerRadius(8)
            .padding(.horizontal)
            .padding(.top)
    }
}

struct HistoryItemView: View {
    let item: HistoryItem
    let onTap: () -> Void
    let onDelete: () -> Void
    
    var body: some View {
        HStack(spacing: 15) {
            KFImage(URL(string: "https://www.google.com/s2/favicons?domain=\(item.url)&sz=64"))
                .placeholder {
                    Circle().fill(Color.gray.opacity(0.3))
                }
                .resizable()
                .frame(width: 40, height: 40)
                .clipShape(Circle())
                .overlay(Circle().stroke(Color.white.opacity(0.1), lineWidth: 1))
            
            VStack(alignment: .leading, spacing: 4) {
                Text(item.title)
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundColor(.white)
                    .lineLimit(1)
                
                Text(item.url)
                    .font(.system(size: 12))
                    .foregroundColor(.white.opacity(0.6))
                    .lineLimit(1)
            }
            
            Spacer()
            
            Button(action: onDelete) {
                Image(systemName: "trash")
                    .foregroundColor(.red.opacity(0.7))
                    .padding(8)
                    .background(Color.white.opacity(0.05))
                    .clipShape(Circle())
            }
        }
        .padding()
        .background(Color.white.opacity(0.08))
        .cornerRadius(12)
        .padding(.horizontal)
        .onTapGesture { onTap() }
    }
}

struct HistoryView: View {
    @ObservedObject var viewModel: WebViewModel
    @ObservedObject var historyManager: HistoryManager
    @Binding var isVisible: Bool
    
    // خلفية متدرجة
    private let backgroundGradient = LinearGradient(
        colors: [Color(hex: "0F2027"), Color(hex: "203A43"), Color(hex: "2C5364")],
        startPoint: .top,
        endPoint: .bottom
    )
    
    // تبسيط منطق تجميع السجل
    var groupedHistory: [(String, [HistoryItem])] {
        let calendar = Calendar.current
        let today = calendar.startOfDay(for: Date())
        let yesterday = calendar.date(byAdding: .day, value: -1, to: today)!
        let weekAgo = calendar.date(byAdding: .day, value: -7, to: today)!
        let monthAgo = calendar.date(byAdding: .month, value: -1, to: today)!
        
        var sections: [(String, [HistoryItem])] = []
        
        let groups = Dictionary(grouping: historyManager.history) { item -> String in
            if item.date >= today { return "اليوم" }
            if item.date >= yesterday { return "الأمس" }
            if item.date >= weekAgo { return "هذا الأسبوع" }
            if item.date >= monthAgo { return "هذا الشهر" }
            return "أقدم"
        }
        
        // ترتيب الأقسام
        let order = ["اليوم", "الأمس", "هذا الأسبوع", "هذا الشهر", "أقدم"]
        for key in order {
            if let items = groups[key], !items.isEmpty {
                sections.append((key, items))
            }
        }
        
        return sections
    }
    
    var body: some View {
        VStack(spacing: 0) {
            headerView
            
            if historyManager.history.isEmpty {
                emptyStateView
            } else {
                historyListView
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        .background(backgroundGradient)
        .edgesIgnoringSafeArea(.all)
    }
    
    // MARK: - Subviews
    
    private var headerView: some View {
        HStack {
            Button(action: { withAnimation(.spring()) { isVisible = false } }) {
                Image(systemName: "xmark.circle.fill")
                    .font(.system(size: 28))
                    .foregroundColor(.white.opacity(0.7))
            }
            Spacer()
            Text("سجل التاريخ")
                .font(.title2)
                .bold()
                .foregroundColor(.white)
            Spacer()
            Button(action: { historyManager.clearAll() }) {
                Image(systemName: "trash.circle.fill")
                    .font(.system(size: 28))
                    .foregroundColor(.red)
            }
        }
        .padding(20)
        .background(Color.black.opacity(0.4))
    }
    
    private var emptyStateView: some View {
        VStack(spacing: 20) {
            Image(systemName: "clock.arrow.circlepath")
                .font(.system(size: 80))
                .foregroundColor(.white.opacity(0.2))
            Text("السجل فارغ تماماً")
                .font(.title3)
                .foregroundColor(.gray)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
    
    private var historyListView: some View {
        ScrollView {
            LazyVStack(spacing: 0) {
                ForEach(groupedHistory, id: \.0) { section in
                    HistorySectionHeader(title: section.0)
                    ForEach(section.1) { item in
                        HistoryItemView(
                            item: item,
                            onTap: { loadHistoryItem(item) },
                            onDelete: { withAnimation { historyManager.deleteItem(item) } }
                        )
                        .padding(.top, 8)
                    }
                }
            }
            .padding(.bottom, 50)
        }
    }
    
    private func loadHistoryItem(_ item: HistoryItem) {
        if let url = URL(string: item.url) {
            viewModel.loadUrl(url: url)
            withAnimation { isVisible = false }
        }
    }
}

// MARK: - NEW: واجهة الكونسول (Console UI)

struct ConsoleView: View {
    @ObservedObject var viewModel: WebViewModel
    @Binding var isVisible: Bool
    @State private var command: String = ""
    
    var body: some View {
        VStack(spacing: 0) {
            // شريط العنوان
            HStack {
                Text("Console (DevTools)")
                    .font(.system(.subheadline, design: .monospaced))
                    .foregroundColor(.white)
                    .bold()
                Spacer()
                Button(action: { viewModel.clearConsole() }) {
                    Image(systemName: "trash")
                        .foregroundColor(.gray)
                }
                .padding(.trailing, 15)
                
                Button(action: { isVisible = false }) {
                    Image(systemName: "xmark")
                        .foregroundColor(.white)
                }
            }
            .padding(10)
            .background(Color(hex: "1a1a1a"))
            
            // منطقة السجلات (Logs)
            ScrollViewReader { proxy in
                ScrollView {
                    LazyVStack(alignment: .leading, spacing: 2) {
                        ForEach(viewModel.consoleLogs) { log in
                            logRow(for: log)
                        }
                    }
                }
                .onChange(of: viewModel.consoleLogs) { _ in
                    if let last = viewModel.consoleLogs.last {
                        withAnimation { proxy.scrollTo(last.id, anchor: .bottom) }
                    }
                }
            }
            .background(Color.black)
            
            // منطقة الإدخال
            inputArea
        }
        .frame(height: 350)
        .background(Color.black)
        .cornerRadius(12)
        .padding()
    }
    
    // MARK: - Subviews & Helpers
    
    private func logRow(for log: ConsoleLog) -> some View {
        HStack(alignment: .top, spacing: 5) {
            Text(log.timestamp, style: .time)
                .font(.system(size: 10, design: .monospaced))
                .foregroundColor(.gray)
                .frame(width: 50, alignment: .leading)
            
            Text(log.message)
                .font(.system(size: 12, design: .monospaced))
                .foregroundColor(colorForLog(log.type))
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(.horizontal, 8)
        .padding(.vertical, 4)
        .background(bgColorForLog(log.type))
        .id(log.id)
    }
    
    private var inputArea: some View {
        HStack {
            Text(">")
                .foregroundColor(.blue)
                .bold()
            
            TextField("Run JavaScript...", text: $command)
                .foregroundColor(.white)
                .font(.system(.body, design: .monospaced))
                .onSubmit(runCommand)
            
            Button(action: runCommand) {
                Image(systemName: "play.fill")
                    .foregroundColor(.blue)
            }
        }
        .padding(8)
        .background(Color(hex: "1a1a1a"))
    }
    
    private func runCommand() {
        if !command.isEmpty {
            viewModel.executeJS(command)
            command = ""
        }
    }
    
    private func colorForLog(_ type: String) -> Color {
        switch type {
        case "error": return .red
        case "warn": return .yellow
        case "info": return .blue
        default: return .white
        }
    }
    
    private func bgColorForLog(_ type: String) -> Color {
        switch type {
        case "error": return Color.red.opacity(0.1)
        case "warn": return Color.yellow.opacity(0.1)
        default: return Color.clear
        }
    }
}

// MARK: - NEW: واجهة مدير السكربتات (Script Manager UI)

struct ScriptManagerView: View {
    @ObservedObject var scriptManager: ScriptManager
    @ObservedObject var viewModel: WebViewModel
    @Binding var isVisible: Bool
    @State private var showingEditor = false
    @State private var scriptToEdit: UserScript?
    
    var body: some View {
        VStack(spacing: 0) {
            headerView
            
            if scriptManager.scripts.isEmpty {
                emptyStateView
            } else {
                scriptsList
            }
        }
        .background(Color.black)
        .fullScreenCover(isPresented: $showingEditor) {
            ScriptEditorView(
                script: scriptToEdit,
                onSave: { newScript in
                    scriptManager.addOrUpdateScript(newScript)
                    viewModel.reload()
                    showingEditor = false
                }
            )
        }
    }
    
    // MARK: - Subviews
    
    private var headerView: some View {
        HStack {
            Button(action: { isVisible = false }) {
                Image(systemName: "xmark")
                    .foregroundColor(.white)
                    .font(.title2)
            }
            Spacer()
            Text("مدير السكربتات")
                .font(.headline)
                .foregroundColor(.white)
            Spacer()
            Button(action: {
                scriptToEdit = nil
                showingEditor = true
            }) {
                Image(systemName: "plus")
                    .foregroundColor(.blue)
                    .font(.title2)
            }
        }
        .padding()
        .background(Color(hex: "1a1a1a"))
    }
    
    private var emptyStateView: some View {
        VStack {
            Spacer()
            Image(systemName: "curlybraces")
                .font(.system(size: 60))
                .foregroundColor(.gray)
            Text("لا توجد سكربتات مضافة")
                .foregroundColor(.gray)
                .padding()
            Spacer()
        }
        .frame(maxWidth: .infinity)
        .background(Color.black)
    }
    
    private var scriptsList: some View {
        List {
            ForEach(scriptManager.scripts) { script in
                scriptRow(for: script)
            }
        }
        .listStyle(PlainListStyle())
        .background(Color.black)
    }
    
    private func scriptRow(for script: UserScript) -> some View {
        HStack {
            VStack(alignment: .leading) {
                Text(script.name)
                    .font(.headline)
                    .foregroundColor(.white)
                Text(script.domain)
                    .font(.caption)
                    .foregroundColor(.gray)
            }
            Spacer()
            
            // تبسيط الـ Binding للـ Toggle
            Toggle("", isOn: binding(for: script))
                .labelsHidden()
                .toggleStyle(SwitchToggleStyle(tint: .blue))
            
            // زر التعديل
            Button(action: {
                scriptToEdit = script
                showingEditor = true
            }) {
                Image(systemName: "pencil")
                    .foregroundColor(.blue)
            }
            .buttonStyle(BorderlessButtonStyle())
            .padding(.leading, 10)
            
            // زر الحذف
            Button(action: {
                scriptManager.deleteScript(script)
                viewModel.reload()
            }) {
                Image(systemName: "trash")
                    .foregroundColor(.red)
            }
            .buttonStyle(BorderlessButtonStyle())
            .padding(.leading, 10)
        }
        .listRowBackground(Color(hex: "2a2a2a"))
    }
    
    // دالة مساعدة لإنشاء Binding للسكربت
    private func binding(for script: UserScript) -> Binding<Bool> {
        Binding(
            get: { script.isActive },
            set: { _ in
                scriptManager.toggleScript(script)
                viewModel.reload()
            }
        )
    }
}

struct ScriptEditorView: View {
    @State var script: UserScript?
    var onSave: (UserScript) -> Void
    @Environment(\.dismiss) var dismiss
    
    @State private var name: String = ""
    @State private var domain: String = "*"
    @State private var code: String = "// اكتب كود جافا سكربت هنا\nconsole.log('Hello');"
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("معلومات السكربت")) {
                    TextField("الاسم", text: $name)
                    TextField("النطاق (* للكل)", text: $domain)
                        .autocapitalization(.none)
                }
                
                Section(header: Text("الكود (JavaScript)")) {
                    TextEditor(text: $code)
                        .font(.system(.body, design: .monospaced))
                        .frame(height: 300)
                }
            }
            .navigationTitle(script == nil ? "سكربت جديد" : "تعديل سكربت")
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("إلغاء") { dismiss() }
                }
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("حفظ", action: saveScript)
                        .disabled(name.isEmpty || code.isEmpty)
                }
            }
            .onAppear(perform: loadData)
        }
        .preferredColorScheme(.dark)
    }
    
    private func loadData() {
        if let s = script {
            name = s.name
            domain = s.domain
            code = s.code
        }
    }
    
    private func saveScript() {
        let newScript = UserScript(
            id: script?.id ?? UUID(),
            name: name,
            domain: domain,
            code: code,
            isActive: script?.isActive ?? true
        )
        onSave(newScript)
    }
}

struct WebsitesBarView: View {
    @ObservedObject var websitesManager: WebsitesManager
    @ObservedObject var viewModel: WebViewModel
    @Binding var isVisible: Bool
    @State private var showAddSheet = false
    
    var body: some View {
        VStack(spacing: 0) {
            headerView
            
            Divider().background(Color.white.opacity(0.1))
            
            if websitesManager.websites.isEmpty {
                emptyStateView
            } else {
                websitesList
            }
        }
        .frame(width: 280)
        .background(Color(hex: "1a1a1a"))
        .edgesIgnoringSafeArea(.bottom)
        .sheet(isPresented: $showAddSheet) {
            AddWebsiteView(websitesManager: websitesManager)
        }
    }
    
    // MARK: - Subviews
    
    private var headerView: some View {
        HStack {
            Button(action: { withAnimation(.spring()) { isVisible = false } }) {
                Image(systemName: "xmark.circle.fill")
                    .font(.system(size: 24))
                    .foregroundColor(.white.opacity(0.7))
            }
            Button(action: { showAddSheet = true }) {
                Image(systemName: "plus.circle.fill")
                    .font(.system(size: 24))
                    .foregroundColor(.blue)
            }
            Spacer()
            VStack(alignment: .trailing) {
                Text("مواقعي").font(.headline).foregroundColor(.white)
                if viewModel.adsBlocked > 0 {
                    Text("تم حظر \(viewModel.adsBlocked) إعلان")
                        .font(.caption2).foregroundColor(.green)
                }
            }
        }
        .padding(15)
    }
    
    private var emptyStateView: some View {
        VStack(spacing: 15) {
            Image(systemName: "globe").font(.system(size: 50)).foregroundColor(.white.opacity(0.3))
            Text("لا توجد مواقع").foregroundColor(.gray)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
    
    private var websitesList: some View {
        ScrollView {
            VStack(spacing: 0) {
                ForEach(websitesManager.websites) { website in
                    WebsiteRowView(website: website, viewModel: viewModel)
                        .onTapGesture { loadWebsite(website) }
                        .contextMenu {
                            Button(role: .destructive) {
                                websitesManager.deleteWebsite(website)
                            } label: {
                                Label("حذف", systemImage: "trash")
                            }
                        }
                }
            }
            .padding(.top, 5)
        }
    }
    
    private func loadWebsite(_ website: Website) {
        if let url = URL(string: website.url) {
            viewModel.loadUrl(url: url)
            withAnimation(.spring()) { isVisible = false }
        }
    }
}

struct WebsiteRowView: View {
    let website: Website
    @ObservedObject var viewModel: WebViewModel
    
    var isCurrentSite: Bool {
        viewModel.currentURL.contains(extractDomain(from: website.url))
    }
    
    var body: some View {
        HStack(spacing: 12) {
            ZStack {
                Circle()
                    .fill(LinearGradient(
                        colors: [Color.blue.opacity(0.8), Color.purple.opacity(0.6)],
                        startPoint: .topLeading,
                        endPoint: .bottomTrailing)
                    )
                    .frame(width: 45, height: 45)
                
                KFImage(URL(string: "https://www.google.com/s2/favicons?domain=\(website.url)&sz=128"))
                    .placeholder {
                        Text(String(website.name.prefix(1)).uppercased())
                            .font(.system(size: 20, weight: .bold))
                            .foregroundColor(.white)
                    }
                    .resizable()
                    .fade(duration: 0.25)
                    .cacheOriginalImage()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 28, height: 28)
                    .clipShape(Circle())
            }
            
            VStack(alignment: .leading, spacing: 4) {
                Text(website.name)
                    .font(.system(size: 15, weight: .semibold))
                    .foregroundColor(.white)
                    .lineLimit(1)
                
                Text(extractDomain(from: website.url))
                    .font(.system(size: 12))
                    .foregroundColor(.white.opacity(0.5))
                    .lineLimit(1)
            }
            
            Spacer()
            
            if isCurrentSite {
                Circle().fill(Color.green).frame(width: 8, height: 8)
            }
        }
        .padding(.horizontal, 15)
        .padding(.vertical, 12)
        .background(isCurrentSite ? Color.white.opacity(0.1) : Color.clear)
        .cornerRadius(10)
        .padding(.horizontal, 10)
    }
    
    func extractDomain(from urlString: String) -> String {
        guard let url = URL(string: urlString), let host = url.host else { return urlString }
        return host.replacingOccurrences(of: "www.", with: "")
    }
}

struct AddWebsiteView: View {
    @ObservedObject var websitesManager: WebsitesManager
    @Environment(\.dismiss) var dismiss
    
    @State var name: String
    @State var url: String
    
    init(websitesManager: WebsitesManager, name: String = "", url: String = "") {
        self.websitesManager = websitesManager
        _name = State(initialValue: name)
        _url = State(initialValue: url)
    }
    
    var body: some View {
        NavigationView {
            Form {
                TextField("الاسم", text: $name)
                TextField("الرابط", text: $url).keyboardType(.URL)
                Button("إضافة", action: addWebsite)
                    .disabled(name.isEmpty || url.isEmpty)
            }
            .navigationTitle("إضافة موقع")
        }
    }
    
    private func addWebsite() {
        let finalUrl = url.lowercased().hasPrefix("http") ? url : "https://\(url)"
        if !name.isEmpty, URL(string: finalUrl) != nil {
            websitesManager.addWebsite(Website(name: name, url: finalUrl))
            dismiss()
        }
    }
}
