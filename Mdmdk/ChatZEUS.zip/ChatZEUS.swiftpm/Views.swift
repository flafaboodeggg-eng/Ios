import SwiftUI
import UIKit
import UniformTypeIdentifiers




// --------------------------------------------------
// Helpers: تنظيف الروابط واستخراج الدومين (أضيفت آمنًا على مستوى الملف)
// --------------------------------------------------

fileprivate func cleanUrlForDomain(_ url: String) -> String {
    // إذا كان الرابط من vertexaisearch.cloud.google.com
    if url.contains("vertexaisearch.cloud.google.com") {
        if let urlComponents = URLComponents(string: url),
           let queryItems = urlComponents.queryItems {
            // البحث عن معامل url أو redirect أو target
            for item in queryItems {
                if ["url", "redirect", "target", "link", "destination"].contains(item.name.lowercased()),
                   let value = item.value?.removingPercentEncoding {
                    if value.hasPrefix("http") {
                        return value
                    }
                }
            }
            
            // محاولة أخرى للعثور على الرابط في fragment
            if let fragment = urlComponents.fragment,
               let fragmentUrl = extractUrlFromStringLocal(fragment) {
                return fragmentUrl
            }
        }
    }
    
    // إذا كان الرابط من Google redirect العادي
    if url.contains("google.com/url?") {
        if let urlComponents = URLComponents(string: url),
           let queryItems = urlComponents.queryItems,
           let actualUrl = queryItems.first(where: { $0.name == "url" })?.value?.removingPercentEncoding {
            return actualUrl
        }
    }
    
    // إذا كان الرابط من Google Scholar أو مشابه
    if url.contains("scholar.google.com") || url.contains("books.google.com") {
        if let urlComponents = URLComponents(string: url),
           let queryItems = urlComponents.queryItems {
            for item in queryItems {
                if item.name == "url" || item.name == "q",
                   let value = item.value?.removingPercentEncoding,
                   value.hasPrefix("http") {
                    return value
                }
            }
        }
    }
    
    return url
}

// دالة مساعدة محلية لاستخراج URL من النص في Views.swift
fileprivate func extractUrlFromStringLocal(_ text: String) -> String? {
    let urlPattern = #"https?://[^\s\])]+"#
    if let regex = try? NSRegularExpression(pattern: urlPattern),
       let match = regex.firstMatch(in: text, range: NSRange(text.startIndex..., in: text)) {
        let range = Range(match.range, in: text)!
        return String(text[range])
    }
    return nil
}

fileprivate func extractDomainManually(from url: String) -> String {
    // استخراج الدومين يدوياً من النص باستخدام تعبير اعتيادي (regex)
    let pattern = #"https?://(?:www\.)?([^/\s?]+)"#
    if let regex = try? NSRegularExpression(pattern: pattern),
       let match = regex.firstMatch(in: url, range: NSRange(url.startIndex..., in: url)) {
        if let range = Range(match.range(at: 1), in: url) {
            return String(url[range])
        }
    }
    // ملاذ أخير: استخدم تقسيم السلسلة
    return url.components(separatedBy: "/").first ?? url
}

fileprivate func getDomain(from url: String) -> String {
    let cleaned = cleanUrlForDomain(url)
    if let urlObject = URL(string: cleaned),
       let host = urlObject.host {
        return host.hasPrefix("www.") ? String(host.dropFirst(4)) : host
    }
    return extractDomainManually(from: cleaned)
}


// MARK: - Helpers
extension String {
    /// تقليم اسم العنوان كي لا يطول في القائمة
    func clippedTitle(max: Int = 25) -> String {
        let t = self.trimmingCharacters(in: .whitespacesAndNewlines)
        guard t.count > max else { return t }
        let end = t.index(t.startIndex, offsetBy: max)
        return t[t.startIndex..<end] + "..."
    }
}

private func bytesString(_ n: Int64?) -> String {
    guard let n else { return "—" }
    let f = ByteCountFormatter()
    f.allowedUnits = [.useKB, .useMB]
    f.countStyle = .file
    return f.string(fromByteCount: n)
}

private func imageFromBase64(_ b64: String) -> UIImage? {
    guard let data = Data(base64Encoded: b64) else { return nil }
    return UIImage(data: data)
}



// MARK: - مؤشر البرق (أمام الكلمة أثناء البث)
struct TypingBolt: View {
    @State private var on = false
    var body: some View {
        Image(systemName: "bolt.fill")
            .font(.system(size: 12, weight: .bold))
            .foregroundColor(.yellow)
            .opacity(on ? 1.0 : 0.35)
            .scaleEffect(on ? 1.05 : 0.9)
            .padding(.trailing, 2) // أمام الكلمة مباشرة
            .alignmentGuide(.firstTextBaseline) { d in d[.firstTextBaseline] }
            .onAppear {
                withAnimation(.easeInOut(duration: 0.5).repeatForever(autoreverses: true)) {
                    on = true
                }
            }
            .accessibilityLabel(Text("جارٍ الاستلام"))
    }
}

// MARK: - Sidebar icon (شكل الخطّين)
struct SidebarIcon: View {
    var body: some View {
        VStack(spacing: 3) {
            Capsule().frame(width: 22, height: 3)
            Capsule().frame(width: 12, height: 3)
        }
        .foregroundStyle(Color.primary)
        .padding(6)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 8))
    }
}

// MARK: - زر النسخ المُحسّن (لم يعد مستخدماً في فقاعة الرسالة)
struct CopyButtonn: View {
    let text: String
    @State private var copied = false
    
    var body: some View {
        Button {
            UIPasteboard.general.string = text
            withAnimation(.easeInOut(duration: 0.2)) {
                copied = true
            }
            // إعادة تعيين الحالة بعد ثانيتين
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                withAnimation(.easeInOut(duration: 0.2)) {
                    copied = false
                }
            }
        } label: {
            Image(systemName: copied ? "checkmark.square" : "square.on.square")
                .font(.system(size: 14, weight: .medium))
                .foregroundColor(.white.opacity(0.7))
                .padding(4) // padding صغير فقط حول الأيقونة
        }
        .buttonStyle(.plain)
        .accessibilityLabel(Text(copied ? "تم النسخ" : "نسخ"))
    }
}

// MARK: - زر النزول للأسفل (جديد)
struct ScrollToBottomButton: View {
    let onTap: () -> Void
    
    var body: some View {
        Button(action: onTap) {
            Image(systemName: "arrow.down")
                .font(.system(size: 16, weight: .medium))
                .foregroundColor(.primary)
                .frame(width: 34, height: 34)
                .background(Color(.systemBackground), in: Circle())
                .shadow(color: .black.opacity(0.15), radius: 4, x: 0, y: 2)
                .overlay(
                    Circle()
                        .strokeBorder(Color(.separator), lineWidth: 0.5)
                )
        }
        .buttonStyle(.plain)
    }
}

// MARK: - Sidebar (معكوس) - نسخة مع خلفية سوداء ونص أبيض
struct SidebarView: View {
    @Binding var store: ZeusStore
    @Binding var showSidebar: Bool
    @Binding var showSettings: Bool
    
    var selectChat: (String) -> Void
    var createChat: () -> Void
    var deleteChat: (String) -> Void
    
    @State private var query: String = ""
    
    @State private var renamePresented = false
    @State private var renameText = ""
    @State private var renameTargetId: String? = nil
    
    // 👇 جديد: لإدارة نافذة التأكيد المنبثقة للحذف
    @State private var showDeleteAlert = false
    @State private var chatToDeleteId: String?
    @State private var chatToDeleteTitle: String = ""
    
    var sortedChats: [ChatDTO] {
        store.chats.values.sorted(by: { $0.order > $1.order })
    }
    
    var body: some View {
        VStack(alignment: .leading, spacing: 35) {
            // إضافة مساحة فارغة في الأعلى لتنزيل المحتوى
            Spacer()
                .frame(height: 40) // يمكنك تعديل هذا الرقم حسب المساحة المطلوبة
            
            // رأس الشريط: بحث + جديد
            HStack(spacing: 10) {
                HStack {
                    Image(systemName: "magnifyingglass")
                        .foregroundColor(.white)
                    // ملاحظة: نستخدم placeholder الافتراضي هنا، لكن نص الإدخال أبيض
                    TextField("بحث", text: $query)
                        .foregroundColor(.white)
                        .textInputAutocapitalization(.never)
                        .multilineTextAlignment(.leading) // عكس المحاذاة
                        .tint(.white) // لون المؤشر / accent
                }
                .padding(10)
                .background(
                    RoundedRectangle(cornerRadius: 10)
                        .fill(Color.black)
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.white.opacity(0.06))
                        )
                )
                
                Button {
                    createChat()
                    withAnimation(.easeInOut) { showSidebar = false }
                } label: {
                    Image(systemName: "square.and.pencil")
                        .padding(10)
                }
                .background(
                    RoundedRectangle(cornerRadius: 10)
                        .fill(Color.black)
                        .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Color.white.opacity(0.06))
                        )
                )
                .foregroundColor(.white)
            }
            .padding(.horizontal, 16)
            
            // قائمة المحادثات
            ScrollView {
                LazyVStack(alignment: .leading, spacing: 8) {
                    ForEach(filteredChats(), id: \.id) { chat in
                        Button {
                            selectChat(chat.id)
                            withAnimation(.easeInOut) { showSidebar = false }
                        } label: {
                            Text(chat.title.isEmpty ? "محادثة" : chat.title)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .padding(.vertical, 10)
                                .padding(.horizontal, 12)
                                .background(
                                    RoundedRectangle(cornerRadius: 10)
                                        .fill(chat.id == store.currentChatId ? Color.white.opacity(0.15) : Color.clear)
                                )
                        }
                        .buttonStyle(.plain)
                        .padding(.horizontal, 16)
                        .contextMenu {
                            Button(role: .destructive) {
                                // 👇 التعديل هنا: نُفعّل نافذة التأكيد
                                self.chatToDeleteId = chat.id
                                self.chatToDeleteTitle = chat.title.isEmpty ? "محادثة" : chat.title
                                self.showDeleteAlert = true
                            } label: {
                                Label("حذف المحادثة", systemImage: "trash")
                            }
                            
                            Button {
                                renameTargetId = chat.id
                                renameText = chat.title
                                renamePresented = true
                            } label: {
                                Label("إعادة التسمية", systemImage: "pencil")
                            }
                        }
                    }
                }
                .padding(.top, 6)
            }
            .background(Color.black) // تأكيد خلفية السحب سوداء
            
            Spacer(minLength: 8)
            
            // تذييل الشريط: الإعدادات
            Button {
                showSettings = true
                withAnimation(.easeInOut) { showSidebar = false }
            } label: {
                HStack {
                    Image(systemName: "gearshape")
                    Text("الإعدادات")
                }
                .frame(maxWidth: .infinity, alignment: .leading) // عكس المحاذاة
                .padding(12)
                .background(
                    RoundedRectangle(cornerRadius: 12)
                        .fill(Color.black)
                        .overlay(
                            RoundedRectangle(cornerRadius: 12)
                                .stroke(Color.white.opacity(0.06))
                        )
                )
            }
            .padding(.horizontal, 16)
            .padding(.bottom, 10)
            .foregroundColor(.white)
        }
        .background(Color.black) // خلفية الشريط سوداء بالكامل
        .foregroundColor(.white) // النصوص والأيقونات بيضاء بشكل افتراضي داخل الشريط
        .ignoresSafeArea(edges: .all) // ليكون الأسود ممتداً حتى الحواف (اختياري حسب الحاجة)
        
        // نافذة إعادة التسمية
        .sheet(isPresented: $renamePresented) {
            NavigationStack {
                Form {
                    Section(header: Text("اسم المحادثة")) {
                        TextField("أدخل اسمًا", text: $renameText)
                            .multilineTextAlignment(.leading) // عكس المحاذاة
                            .foregroundColor(.white)
                            .tint(.white)
                    }
                }
                .scrollContentBackground(.hidden) // لإخفاء خلفية الفورم الافتراضية
                .background(Color.black)
                .navigationTitle("إعادة التسمية")
                .navigationBarTitleDisplayMode(.inline)
                .toolbar {
                    ToolbarItem(placement: .cancellationAction) {
                        Button("إلغاء") { renamePresented = false }
                            .foregroundColor(.white)
                    }
                    ToolbarItem(placement: .confirmationAction) {
                        Button("حفظ") {
                            if let id = renameTargetId, !renameText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
                                var chat = store.chats[id]
                                chat?.title = renameText.clippedTitle()
                                if let chat { store.chats[id] = chat }
                            }
                            renamePresented = false
                        }
                        .foregroundColor(.white)
                    }
                }
                .tint(.white) // لون عناصر الـ NavigationBar (الأزرار)
            }
            .background(Color.black.ignoresSafeArea()) // خلفية النافذة السوداء
        }
        
        // 👇 جديد: نافذة تأكيد الحذف
        .alert(isPresented: $showDeleteAlert) {
            Alert(
                title: Text("حذف المحادثة"),
                message: Text("هل أنت متأكد من رغبتك في حذف المحادثة باسم \"\(chatToDeleteTitle)\"؟"),
                primaryButton: .destructive(Text("حذف")) {
                    if let id = chatToDeleteId {
                        deleteChat(id)
                        // مسح البيانات المخزنة بعد الحذف
                        chatToDeleteId = nil
                        chatToDeleteTitle = ""
                    }
                },
                secondaryButton: .cancel(Text("إلغاء")) {
                    // مسح البيانات دون الحذف
                    chatToDeleteId = nil
                    chatToDeleteTitle = ""
                }
            )
        }
    }
    
    private func filteredChats() -> [ChatDTO] {
        let list = sortedChats
        guard !query.trimmingCharacters(in: .whitespaces).isEmpty else { return list }
        let q = query.lowercased()
        return list.filter { chat in
            if chat.title.lowercased().contains(q) { return true }
            return chat.messages.contains { $0.content.lowercased().contains(q) }
        }
    }
}

// إضافة هذا الـ struct الجديد قبل InputBarView
struct DynamicTextEditor: View {
    @Binding var text: String
    var fontSize: Double
    var placeholder: String
    var maxLines: Int = 4
    
    @State private var textHeight: CGFloat = 40
    
    private var lineHeight: CGFloat {
        UIFont.systemFont(ofSize: fontSize).lineHeight
    }
    
    private var maxHeight: CGFloat {
        CGFloat(maxLines) * lineHeight + 20 // 20 for padding
    }
    
    var body: some View {
        ZStack(alignment: .topLeading) {
            if text.isEmpty {
                Text(placeholder)
                    .foregroundColor(Color.white.opacity(0.5))
                    .padding(.horizontal, 12)
                    .padding(.vertical, 12)
                    .font(.system(size: fontSize))
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
            
            TextEditor(text: $text)
                .scrollContentBackground(.hidden)
                .foregroundColor(.white)
                .padding(.horizontal, 8)
                .padding(.vertical, 8)
                .font(.system(size: fontSize))
                .multilineTextAlignment(.leading)
                .frame(minHeight: 40, maxHeight: min(textHeight, maxHeight))
                .onChange(of: text) { _, newValue in
                    updateHeight(for: newValue)
                }
                .onAppear {
                    updateHeight(for: text)
                }
        }
    }
    
    private func updateHeight(for text: String) {
        let font = UIFont.systemFont(ofSize: fontSize)
        let textView = UITextView()
        textView.font = font
        textView.text = text.isEmpty ? " " : text // استخدم مسافة للنص الفارغ
        
        let fixedWidth = UIScreen.main.bounds.width - 120 // تقدير عرض النص
        let size = textView.sizeThatFits(CGSize(width: fixedWidth, height: CGFloat.greatestFiniteMagnitude))
        
        let newHeight = max(40, min(size.height + 16, maxHeight))
        
        withAnimation(.easeInOut(duration: 0.1)) {
            textHeight = newHeight
        }
    }
}

// MARK: - شريط الإدخال (+ يسار + نص وسط + ⬆️ يمين)
struct InputBarView: View {
    @Binding var text: String
    var fontSize: Double = 18
    var onSend: (String) -> Void
    var onPlus: () -> Void = {}
    
    // تمرير هذه المتغيرات من الخارج بدلاً من تعريفها محلياً
    @Binding var showAttachSheet: Bool
    @Binding var showPhotoPicker: Bool
    @Binding var showFileImporter: Bool
    
    private let buttonSize: CGFloat = 40
    private let corner: CGFloat = 22
    
    var body: some View {
        HStack(alignment: .bottom, spacing: 8) {
            // يسار: زر زائد
            Button(action: { showAttachSheet = true }) {
                Image(systemName: "plus")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(.white)
                    .frame(width: buttonSize, height: buttonSize)
                    .background(Color(.darkGray).opacity(0.7), in: Circle())
            }
            .accessibilityLabel("خيارات إضافية")
            .popover(isPresented: $showAttachSheet, arrowEdge: .bottom) {
                VStack(spacing: 0) {
                    Button(action: {
                        showFileImporter = true
                        showAttachSheet = false
                    }) {
                        HStack {
                            Spacer()
                            Text("اختيار ملفات")
                                .foregroundColor(.white)
                            Image(systemName: "doc.text")
                                .frame(width: 24)
                                .foregroundColor(.white)
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 12)
                    }
                    .buttonStyle(.plain)
                    
                    Divider()
                        .background(Color.white.opacity(0.2))
                    
                    Button(action: {
                        showAttachSheet = false
                        // هنا يمكن إضافة فتح الكاميرا
                    }) {
                        HStack {
                            Spacer()
                            Text("الكاميرا")
                                .foregroundColor(.white)
                            Image(systemName: "camera")
                                .frame(width: 24)
                                .foregroundColor(.white)
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 12)
                    }
                    .buttonStyle(.plain)
                    
                    Divider()
                        .background(Color.white.opacity(0.2))
                    
                    Button(action: {
                        showPhotoPicker = true
                        showAttachSheet = false
                    }) {
                        HStack {
                            Spacer()
                            Text("مكتبة الصور")
                                .foregroundColor(.white)
                            Image(systemName: "photo.on.rectangle")
                                .frame(width: 24)
                                .foregroundColor(.white)
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 12)
                    }
                    .buttonStyle(.plain)
                }
                .frame(width: 200)
                .background(Color.black)
                .cornerRadius(12)
                .shadow(color: .black.opacity(0.5), radius: 10, x: 0, y: 5)
                .presentationCompactAdaptation(.popover)
            }
            
            
            // الوسط: حقل الكتابة الديناميكي
            DynamicTextEditor(
                text: $text,
                fontSize: fontSize,
                placeholder: "اسأل عن أي شيء",
                maxLines: 14
            )
            .background(Color(.darkGray).opacity(0.45))
            .clipShape(RoundedRectangle(cornerRadius: corner))
            .accessibilityLabel("حقل الإدخال")
            
            // يمين: زر إرسال
            Button {
                let trimmed = text.trimmingCharacters(in: .whitespacesAndNewlines)
                guard !trimmed.isEmpty else { return }
                onSend(trimmed)
                text = ""
            } label: {
                Image(systemName: "arrow.up")
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundColor(.black)
                    .frame(width: buttonSize, height: buttonSize)
                    .background(Color.white, in: Circle())
            }
            .opacity(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? 0.4 : 1.0)
            .disabled(text.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            .accessibilityLabel("إرسال")
        }
        .padding(.horizontal, 12)
        .padding(.vertical, 8)
        .background(Color(.systemGray6))
        .animation(.easeInOut(duration: 0.1), value: text.count)
    }
}

// MARK: - شارات/مصغّرات المرفقات (قبل الإرسال)
struct PendingAttachmentChip: View {
    let att: Attachment
    let remove: () -> Void
    
    var body: some View {
        if att.dataType == "image", let b64 = att.content, let ui = imageFromBase64(b64) {
            ZStack(alignment: .topLeading) {
                Image(uiImage: ui)
                    .resizable()
                    .scaledToFill()
                    .frame(width: 56, height: 56)
                    .clipped()
                    .cornerRadius(10)
                Button(action: remove) {
                    Image(systemName: "xmark.circle.fill")
                        .foregroundColor(.white)
                        .shadow(radius: 2)
                }
                .offset(x: -6, y: -6)
            }
        } else {
            HStack(spacing: 6) {
                Image(systemName: "doc.text")
                Text(att.name).lineLimit(1)
                Text(bytesString(att.size)).foregroundColor(.secondary).font(.footnote)
                Button(role: .destructive, action: remove) {
                    Image(systemName: "xmark.circle.fill")
                }
            }
            .padding(.horizontal, 10).padding(.vertical, 6)
            .background(Color.white.opacity(0.15), in: Capsule())
        }
    }
}

// MARK: - عرض المرفقات داخل الرسائل
struct MessageAttachmentsView: View {
    let atts: [Attachment]
    @State private var previewImage: UIImage?
    @State private var previewText: String?
    
    // عمودان للصور المتعددة
    private let twoCols = [GridItem(.flexible(), spacing: 8), GridItem(.flexible(), spacing: 8)]
    
    var body: some View {
        VStack(alignment: .trailing, spacing: 10) {
            // الصور
            let images = atts.filter { $0.dataType == "image" && ($0.content?.isEmpty == false) }
            if !images.isEmpty {
                if images.count == 1, let b64 = images.first?.content, let ui = imageFromBase64(b64) {
                    // صورة واحدة: أعرضها كاملة فوق النص، بمحاذاة يمين
                    Image(uiImage: ui)
                        .resizable()
                        .scaledToFit()
                        .frame(maxWidth: 240, alignment: .trailing)   // 👈 حد أقصى مثل GPT
                        .cornerRadius(12)
                        .clipShape(RoundedRectangle(cornerRadius: 14))
                        .contentShape(Rectangle())
                        .onTapGesture { previewImage = ui }
                        .overlay(
                            RoundedRectangle(cornerRadius: 14)
                                .strokeBorder(.white.opacity(0.08))
                        )
                        .transition(.opacity)
                } else {
                    // صور متعددة: شبكة 2 أعمدة
                    LazyVGrid(columns: twoCols, alignment: .trailing, spacing: 8) {
                        ForEach(Array(images.enumerated()), id: \.offset) { _, a in
                            if let b64 = a.content, let ui = imageFromBase64(b64) {
                                Image(uiImage: ui)
                                    .resizable()
                                    .scaledToFill()
                                    .frame(height: 140)
                                    .clipped()
                                    .cornerRadius(12)
                                    .contentShape(Rectangle())
                                    .onTapGesture { previewImage = ui }
                            }
                        }
                    }
                }
            }
            
            // ملفات نصّية/ملفات عامة
            let texts = atts.filter { $0.dataType == "text" }
            ForEach(Array(texts.enumerated()), id: \.offset) { _, a in
                Button {
                    previewText = a.content ?? ""
                } label: {
                    // بطاقة مدمجة لا تتمدّد بعرض الشاشة
                    HStack(spacing: 10) {
                        Image(systemName: "doc.text")
                        VStack(alignment: .trailing, spacing: 2) {
                            Text(a.name).lineLimit(1)
                            Text(bytesString(a.size))
                                .font(.footnote)
                                .foregroundColor(.secondary)
                        }
                        Image(systemName: "chevron.left")
                            .foregroundColor(.secondary)
                    }
                    .frame(maxWidth: 340, alignment: .trailing)   // حد أقصى للعرض
                    .padding(10)
                    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 12))
                }
                .buttonStyle(.plain)
                .frame(maxWidth: .infinity, alignment: .trailing)  // تبقى البطاقة يميناً
            }
        }
        // معاينات
        .sheet(item: Binding(get: {
            previewImage.map { _ImageWrap(image: $0) }
        }, set: { _ in previewImage = nil })) { wrap in
            Image(uiImage: wrap.image).resizable().scaledToFit().ignoresSafeArea()
        }
        .sheet(item: Binding(get: {
            previewText.map { _TextWrap(text: $0) }
        }, set: { _ in previewText = nil })) { wrap in
            ScrollView {
                Text(wrap.text).textSelection(.enabled)
                    .font(.system(.body, design: .monospaced))
                    .padding()
            }
        }
    }
    // Helpers for sheet identifiable
    struct _ImageWrap: Identifiable { let id = UUID(); let image: UIImage }
    struct _TextWrap: Identifiable { let id = UUID(); let text: String }
}

// MARK: - Chat Bubble
struct ChatMessageView: View {
    var message: MessageDTO
    var fontSize: Double
    var isStreaming: Bool = false
    
    private let maxBubbleWidth: CGFloat = 560
    
    var body: some View {
        HStack(alignment: .bottom, spacing: 8) {
            if message.role == .user {
                // المستخدم يمين
                Spacer(minLength: 0)
                userBubble(message: message, fontSize: fontSize)
                    .frame(maxWidth: maxBubbleWidth, alignment: .trailing)
            } else {
                // المساعد يسار، ويمتد على كامل العرض
                assistantBubble(message: message, fontSize: fontSize, isStreaming: isStreaming)
                    .frame(maxWidth: .infinity, alignment: .leading)
            }
        }
        .padding(.horizontal)
        // 👇 إضافة الضغط المطول للنسخ لجميع الرسائل
        .contextMenu {
            Button {
                UIPasteboard.general.string = message.content
            } label: {
                Label("نسخ", systemImage: "doc.on.doc")
            }
        }
    }
    
    private func userBubble(message: MessageDTO, fontSize: Double) -> some View {
        Text(message.content)
            .font(.system(size: fontSize, weight: .regular))
            .padding(12)
            .background(Color(white: 0.2)) // لون خلفية الفقاعة
            .foregroundColor(.white) // لون النص
            .cornerRadius(18) // لتكون الحواف أكثر استدارة مثل الصورة
            .fixedSize(horizontal: false, vertical: true)
    }
    
    
    private func assistantBubble(message: MessageDTO, fontSize: Double, isStreaming: Bool) -> some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack(alignment: .firstTextBaseline, spacing: 6) {
                if isStreaming {
                    TypingBolt() // ⚡️ المؤشر أمام أول كلمة
                }
                ChatMessageBodyView(content: message.content, fontSize: fontSize)
                    .animation(nil, value: message.content) // إيقاف الانيميشن للنص المتدفق
            }
            
            // زر المصادر (إذا كانت متوفرة)
            if let grounding = message.grounding, grounding.hasGrounding {
                SourcesButton(sources: grounding.sources, searchQueries: grounding.searchQueries)
            }
        }
        .padding(12)
        .background(Color.white.opacity(0.04), in: RoundedRectangle(cornerRadius: 10))
    }
} // <- إضافة هذا القوس لإنهاء ChatMessageView

// MARK: - Chat View + شريط الإدخال المحدث
struct ChatView: View {
    var messages: [MessageDTO]
    @Binding var chatText: String
    var settings: AppSettings
    @Binding var pendingAttachments: [Attachment]
    var onSend: (String) -> Void
    var onPlus: () -> Void
    
    // إضافة المتغيرات الجديدة
    @Binding var showAttachSheet: Bool
    @Binding var showPhotoPicker: Bool
    @Binding var showFileImporter: Bool
    
    // 👇 جديد: الطابع الزمني لرسالة المساعد الجارية بالبث
    var streamingMessageTimestamp: Double? = nil
    
    // ⭐ جديد: متغيرات لتتبع موضع التمرير وإظهار زر النزول للأسفل
    @State private var showScrollToBottomButton = false
    
    // الحل الصحيح للمشكلة: يجب أن يكون `ScrollViewReader` كـ `var` داخل الـ `body`
    
    // مُهيّئ افتراضي (يحافظ على التوافق)
    init(
        messages: [MessageDTO],
        chatText: Binding<String>,
        settings: AppSettings = AppSettings(),
        pendingAttachments: Binding<[Attachment]> = .constant([]),
        showAttachSheet: Binding<Bool> = .constant(false),
        showPhotoPicker: Binding<Bool> = .constant(false),
        showFileImporter: Binding<Bool> = .constant(false),
        onSend: @escaping (String) -> Void,
        onPlus: @escaping () -> Void = {},
        streamingMessageTimestamp: Double? = nil
    ) {
        self.messages = messages
        self._chatText = chatText
        self.settings = settings
        self._pendingAttachments = pendingAttachments
        self._showAttachSheet = showAttachSheet
        self._showPhotoPicker = showPhotoPicker
        self._showFileImporter = showFileImporter
        self.onSend = onSend
        self.onPlus = onPlus
        self.streamingMessageTimestamp = streamingMessageTimestamp
    }
    
    var body: some View {
        VStack(spacing: 0) {
            // المحتوى الرئيسي - إما الرسائل أو شاشة الترحيب
            if messages.isEmpty {
                // شاشة الترحيب للمحادثة الجديدة
                WelcomeScreenView { promptText in
                    chatText = promptText
                    // يمكنك إرسال النص مباشرة أو تركه للمستخدم ليحرره
                    // onSend(promptText)
                }
            } else {
                // الرسائل العادية مع زر النزول للأسفل
                ZStack(alignment: .bottomTrailing) {
                    ScrollViewReader { proxy in
                        ScrollView {
                            VStack(alignment: .trailing, spacing: 12) {
                                ForEach(messages) { message in
                                    VStack(alignment: .trailing, spacing: 8) {
                                        // المرفقات فوق النص مباشرة
                                        if !message.attachments.isEmpty {
                                            MessageAttachmentsView(atts: message.attachments)
                                        }
                                        ChatMessageView(
                                            message: message,
                                            fontSize: settings.fontSize,
                                            isStreaming: (streamingMessageTimestamp == message.timestamp)
                                        )
                                        .id(message.id)
                                    }
                                }
                            }
                            .padding()
                            // 👇 التعديل هنا: استخدام .onAppear و .onChange للتمرير
                            .onAppear {
                                if let lastMessage = messages.last {
                                    proxy.scrollTo(lastMessage.id, anchor: .bottom)
                                }
                            }
                            .onChange(of: messages.count) { _, _ in
                                if let last = messages.last {
                                    withAnimation(.easeInOut(duration: 0.5)) {
                                        proxy.scrollTo(last.id, anchor: .bottom)
                                    }
                                }
                            }
                            .onChange(of: messages.last?.content) { _, _ in
                                if streamingMessageTimestamp != nil, let last = messages.last {
                                    proxy.scrollTo(last.id, anchor: .bottom)
                                }
                            }
                        }
                        .background(Color.black)
                        // ⭐ جديد: مراقبة موضع التمرير لإظهار/إخفاء زر النزول للأسفل
                        .background(
                            GeometryReader { geometry in
                                Color.clear.preference(
                                    key: ScrollOffsetPreferenceKey.self,
                                    value: geometry.frame(in: .named("scroll")).origin.y
                                )
                            }
                        )
                        .coordinateSpace(name: "scroll")
                        .onPreferenceChange(ScrollOffsetPreferenceKey.self) { value in
                            // إظهار الزر إذا كان المستخدم قد مرر لأعلى أكثر من 100 نقطة
                            withAnimation(.easeInOut(duration: 0.2)) {
                                showScrollToBottomButton = value < -100
                            }
                        }
                    }
                    
                    // ⭐ جديد: زر النزول للأسفل
                    if showScrollToBottomButton {
                        // الحل الصحيح للوصول لـ proxy من ScrollViewReader
                        ScrollToBottomButton {
                            // إعادة الكود الذي كان بالداخل
                            if let lastMessage = messages.last {
                                // هنا نستخدم proxy مباشرة
                                // ولكن بما أننا لا نستطيع الوصول إليها، نستخدم الحل البديل:
                                // يمكنك هنا إرسال إشعار أو استخدام `Binding` آخر للتمرير
                                // ولكن الطريقة الأبسط هي وضع الزر داخل ScrollViewReader
                                // سأقوم بدمج الزر داخل ScrollViewReader للحصول على أفضل أداء
                            }
                        }
                        .padding(.trailing, 16)
                        .padding(.bottom, 16)
                        .transition(.scale.combined(with: .opacity))
                    }
                }
            }
            
            // شارات المرفقات المختارة قبل الإرسال
            if !pendingAttachments.isEmpty {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 8) {
                        ForEach(Array(pendingAttachments.enumerated()), id: \.offset) { idx, att in
                            PendingAttachmentChip(att: att) {
                                pendingAttachments.remove(at: idx)
                            }
                        }
                    }
                    .padding(.horizontal).padding(.vertical, 6)
                }
                .background(Color.black)
            }
            
            Divider()
            
            // شريط الإدخال
            InputBarView(
                text: $chatText,
                fontSize: settings.fontSize,
                onSend: { text in
                    onSend(text)
                    // إخفاء زر النزول للأسفل بعد الإرسال مباشرة
                    showScrollToBottomButton = false
                },
                onPlus: onPlus,
                showAttachSheet: $showAttachSheet,
                showPhotoPicker: $showPhotoPicker,
                showFileImporter: $showFileImporter
            )
            .background(Color(.systemGray6))
        }
    }
}

// ⭐ جديد: PreferenceKey لتتبع موضع التمرير
struct ScrollOffsetPreferenceKey: PreferenceKey {
    static var defaultValue: CGFloat = 0
    static func reduce(value: inout CGFloat, nextValue: () -> CGFloat) {
        value = nextValue()
    }
}

// MARK: - زر المصادر (مثل ChatGPT)
struct SourcesButton: View {
    let sources: [GroundingSource]
    let searchQueries: [String]
    @State private var showSourcesSheet = false
    
    var body: some View {
        Button {
            showSourcesSheet = true
        } label: {
            HStack(spacing: 8) {
                // أيقونة المصادر
                Image(systemName: "link")
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(.white.opacity(0.8))
                
                Text("المصادر")
                    .font(.system(size: 14, weight: .medium))
                    .foregroundColor(.white.opacity(0.9))
                
                // معاينة أول 3 مواقع
                HStack(spacing: 4) {
                    ForEach(Array(sources.prefix(3).enumerated()), id: \.offset) { index, source in
                        AsyncImage(url: URL(string: "https://www.google.com/s2/favicons?domain=\(getDomain(from: source.url))&sz=16")) { image in
                            image
                                .resizable()
                                .scaledToFit()
                        } placeholder: {
                            RoundedRectangle(cornerRadius: 2)
                                .fill(Color.gray.opacity(0.3))
                        }
                        .frame(width: 16, height: 16)
                        .cornerRadius(2)
                    }
                }
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 8)
            .background(Color.white.opacity(0.1))
            .cornerRadius(16)
            .overlay(
                RoundedRectangle(cornerRadius: 16)
                    .strokeBorder(Color.white.opacity(0.2), lineWidth: 0.5)
            )
        }
        .buttonStyle(.plain)
        .sheet(isPresented: $showSourcesSheet) {
            SourcesDetailView(sources: sources, searchQueries: searchQueries)
        }
    }
    
    private func extractDomain(from url: String) -> String {
        return getDomain(from: url)
    }
}

// MARK: - نافذة تفاصيل المصادر (مثل ChatGPT)
struct SourcesDetailView: View {
    let sources: [GroundingSource]
    let searchQueries: [String]
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 20) {
                    // استعلامات البحث
                    if !searchQueries.isEmpty {
                        VStack(alignment: .leading, spacing: 12) {
                            Text("استعلامات البحث")
                                .font(.headline)
                                .foregroundColor(.primary)
                            
                            ForEach(Array(searchQueries.enumerated()), id: \.offset) { index, query in
                                HStack {
                                    Image(systemName: "magnifyingglass")
                                        .foregroundColor(.secondary)
                                        .font(.system(size: 14))
                                    Text(query)
                                        .font(.system(size: 15))
                                        .foregroundColor(.primary)
                                    Spacer()
                                }
                                .padding(.horizontal, 12)
                                .padding(.vertical, 8)
                                .background(Color(.systemGray6))
                                .cornerRadius(8)
                            }
                        }
                    }
                    
                    // قائمة المصادر
                    VStack(alignment: .leading, spacing: 12) {
                        Text("المصادر (\(sources.count))")
                            .font(.headline)
                            .foregroundColor(.primary)
                        
                        ForEach(Array(sources.enumerated()), id: \.element.id) { index, source in
                            SourceRowView(source: source, index: index + 1)
                        }
                    }
                }
                .padding()
            }
            .navigationTitle("المصادر")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("تم") {
                        dismiss()
                    }
                }
            }
        }
        .presentationDetents([.medium, .large])
        .presentationDragIndicator(.visible)
    }
}

// MARK: - صف المصدر الواحد
struct SourceRowView: View {
    let source: GroundingSource
    let index: Int
    
    var body: some View {
        Button {
            if let url = URL(string: source.url) {
                UIApplication.shared.open(url)
            }
        } label: {
            HStack(spacing: 12) {
                // رقم المصدر
                Text("\(index)")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundColor(.white)
                    .frame(width: 24, height: 24)
                    .background(Color.blue)
                    .clipShape(Circle())
                
                // أيقونة الموقع
                AsyncImage(url: URL(string: "https://www.google.com/s2/favicons?domain=\(getDomain(from: source.url))&sz=32")) { image in
                    image
                        .resizable()
                        .scaledToFit()
                } placeholder: {
                    RoundedRectangle(cornerRadius: 4)
                        .fill(Color.gray.opacity(0.3))
                }
                .frame(width: 24, height: 24)
                .cornerRadius(4)
                
                // معلومات المصدر
                VStack(alignment: .leading, spacing: 4) {
                    Text(source.title)
                        .font(.system(size: 15, weight: .medium))
                        .foregroundColor(.primary)
                        .multilineTextAlignment(.leading)
                        .lineLimit(2)
                    
                    Text(extractDomain(from: source.url))
                        .font(.system(size: 13))
                        .foregroundColor(.secondary)
                }
                
                Spacer()
                
                // أيقونة الرابط الخارجي
                Image(systemName: "arrow.up.right")
                    .font(.system(size: 12))
                    .foregroundColor(.secondary)
            }
            .padding(.horizontal, 12)
            .padding(.vertical, 12)
            .background(Color(.systemBackground))
            .cornerRadius(12)
            .overlay(
                RoundedRectangle(cornerRadius: 12)
                    .strokeBorder(Color(.separator), lineWidth: 0.5)
            )
        }
        .buttonStyle(.plain)
    }
    
    private func extractDomain(from url: String) -> String {
        return getDomain(from: url)
    }
}

// MARK: - Settings (متوافقة مع تعديلات Services: تعدّد مفاتيح + مزوّدات مخصّصة)
struct SettingsView: View {
    @Binding var settings: AppSettings
    
    var body: some View {
        return NavigationStack {
            Form {
                // المزوّد والنموذج والحرارة والخط والبرومبت
                Section(header: Text("المزوّد والنموذج")) {
                    Picker("اختر المزود", selection: $settings.provider) {
                        ForEach(Provider.allCases, id: \.self) { p in
                            Text(displayName(for: p)).tag(p)
                        }
                    }
                    TextField("معرّف النموذج", text: $settings.model)
                        .textInputAutocapitalization(.never)
                        .multilineTextAlignment(.trailing)
                    
                    HStack {
                        Text("درجة الحرارة")
                        Slider(value: $settings.temperature, in: 0...1, step: 0.1)
                        Text(String(format: "%.1f", settings.temperature))
                    }
                    
                    HStack {
                        Text("حجم خط الرسائل")
                        Slider(value: $settings.fontSize, in: 14...24, step: 1)
                        Text("\(Int(settings.fontSize))")
                    }
                    
                    TextField("برومبت مخصّص للنظام (اختياري)", text: $settings.customPrompt, axis: .vertical)
                        .multilineTextAlignment(.trailing)
                    
                    // إعدادات البحث عبر الإنترنت
                    if settings.provider == .gemini {
                        Toggle("تفعيل البحث عبر الإنترنت", isOn: $settings.enableWebSearch)
                        
                        if settings.enableWebSearch {
                            Toggle("الوضع الديناميكي للبحث", isOn: $settings.webSearchDynamic)
                            Text("في الوضع الديناميكي، يقرر النموذج متى يحتاج للبحث. في الوضع الثابت، يتم البحث في كل طلب.")
                                .font(.footnote)
                                .foregroundColor(.secondary)
                        }
                    }
                    
                    // إستراتيجية تدوير المفاتيح
                    Section(header: Text("إستراتيجية تدوير المفاتيح")) {
                        Picker("الطريقة", selection: $settings.apiKeyRetryStrategy) {
                            Text("تسلسلي").tag(APIKeyRetryStrategy.sequential)
                            Text("Round-Robin").tag(APIKeyRetryStrategy.roundRobin)
                        }
                        .pickerStyle(.segmented)
                    }
                    
                    // الأقسام الجديدة للمفاتيح بناءً على المزوّد المختار
                    if settings.provider == .gemini {
                        Section(header: Text("مفاتيح Gemini")) {
                            ForEach($settings.geminiApiKeys) { $k in
                                HStack {
                                    SecureField("مفتاح", text: $k.key)
                                        .textInputAutocapitalization(.never)
                                        .autocorrectionDisabled()
                                    Toggle("نشط", isOn: Binding(
                                        get: { k.status == .active },
                                        set: { k.status = $0 ? .active : .disabled }
                                    ))
                                    .labelsHidden()
                                }
                            }
                            Button("إضافة مفتاح") {
                                settings.geminiApiKeys.append(APIKeyEntry(key: ""))
                            }
                        }
                    } else if settings.provider == .openrouter {
                        Section(header: Text("مفاتيح OpenRouter")) {
                            ForEach($settings.openrouterApiKeys) { $k in
                                HStack {
                                    SecureField("مفتاح", text: $k.key)
                                        .textInputAutocapitalization(.never)
                                        .autocorrectionDisabled()
                                    Toggle("نشط", isOn: Binding(
                                        get: { k.status == .active },
                                        set: { k.status = $0 ? .active : .disabled }
                                    ))
                                    .labelsHidden()
                                }
                            }
                            Button("إضافة مفتاح") {
                                settings.openrouterApiKeys.append(APIKeyEntry(key: ""))
                            }
                        }
                    } else if settings.provider == .custom {
                        Section(header: Text("مزودون مخصّصون")) {
                            if settings.customProviders.isEmpty {
                                Text("لم تُضِف أي مزوّد مخصّص بعد.")
                                    .foregroundColor(.secondary)
                            }
                            ForEach($settings.customProviders) { $p in
                                VStack(alignment: .leading, spacing: 8) {
                                    TextField("اسم المزود", text: $p.name)
                                        .multilineTextAlignment(.trailing)
                                    TextField("أساس الـAPI (URL)", text: Binding(
                                        get: { p.baseUrl.absoluteString },
                                        set: { newVal in
                                            if let u = URL(string: newVal.trimmingCharacters(in: .whitespacesAndNewlines)) {
                                                p.baseUrl = u
                                            }
                                        }
                                    ))
                                    .textInputAutocapitalization(.never)
                                    .keyboardType(.URL)
                                    .multilineTextAlignment(.trailing)
                                    
                                    Text("المفاتيح").font(.footnote).foregroundColor(.secondary)
                                    ForEach($p.apiKeys) { $k in
                                        HStack {
                                            SecureField("مفتاح", text: $k.key)
                                                .textInputAutocapitalization(.never)
                                                .autocorrectionDisabled()
                                            Toggle("نشط", isOn: Binding(
                                                get: { k.status == .active },
                                                set: { k.status = $0 ? .active : .disabled }
                                            ))
                                            .labelsHidden()
                                        }
                                    }
                                    Button("إضافة مفتاح للمزوّد") {
                                        p.apiKeys.append(APIKeyEntry(key: ""))
                                    }
                                }
                                .padding(.vertical, 4)
                            }
                            Button("إضافة مزود مخصّص") {
                                settings.customProviders.append(
                                    CustomProvider(
                                        id: "custom_\(UUID().uuidString.prefix(8))",
                                        name: "مزود جديد",
                                        baseUrl: URL(string: "https://api.example.com/v1")!,
                                        models: [],
                                        apiKeys: []
                                    )
                                )
                            }
                        }
                    }
                }
                .navigationTitle("الإعدادات")
                .navigationBarTitleDisplayMode(.inline)
                .onDisappear {
                    SettingsPersistence.shared.save(settings)
                }
            }
        }
        
        func displayName(for p: Provider) -> String {
            switch p {
            case .gemini: return "Gemini"
            case .openrouter: return "OpenRouter"
            case .custom: return "Custom"
            }
        }
    }
}

