import Foundation

// ======================================================================
// MARK: - المزوّدون والمفاتيح
// ======================================================================

enum Provider: String, Codable, CaseIterable {
    case gemini
    case openrouter
    case custom
}

enum APIKeyStatus: String, Codable { case active, disabled }

struct APIKeyEntry: Codable, Equatable, Identifiable {
    var id = UUID()
    var key: String
    var status: APIKeyStatus = .active
}

enum APIKeyRetryStrategy: String, Codable { case sequential, roundRobin }

// ======================================================================
// MARK: - مزوّدون/نماذج مخصّصة
// ======================================================================

struct CustomModel: Codable, Equatable, Identifiable {
    var id: String              // مثال: "my-model-1"
    var name: String            // اسم العرض
    var providerId: String?     // ربطه بالمزوّد المخصّص
    var defaultTemperature: Double?
    var description: String?
}

struct CustomProvider: Codable, Equatable, Identifiable {
    var id: String              // مثال: "custom_123"
    var name: String            // مثال: "مزود مؤسّسي"
    var baseUrl: URL            // جذر الـ API (مثلاً: https://api.example.com/v1)
    var models: [CustomModel] = []
    var apiKeys: [APIKeyEntry] = []
}

// ======================================================================
// MARK: - الإعدادات العامة للتطبيق (متوافقة مع Services)
// ======================================================================

struct AppSettings: Codable, Equatable {
    var provider: Provider = .gemini
    var model: String = "gemini-1.5-flash"
    var temperature: Double = 0.7
    var fontSize: Double = 18
    var customPrompt: String = ""
    
    var apiKeyRetryStrategy: APIKeyRetryStrategy = .sequential
    var geminiApiKeys: [APIKeyEntry] = []
    var openrouterApiKeys: [APIKeyEntry] = []
    
    var customProviders: [CustomProvider] = []
    var customModels: [CustomModel] = []
    
    // إعدادات البحث عبر الإنترنت
    var enableWebSearch: Bool = false
    var webSearchDynamic: Bool = true
}

// ======================================================================
// MARK: - نماذج المحادثة (مطابقة لبنية الويب ومستخدمة في Services)
// ======================================================================

enum SenderRole: String, Codable { case user, assistant }

struct Attachment: Codable, Equatable {
    var name: String
    var size: Int64?
    var type: String?      // MIME type (مثل: image/png أو text/plain)
    var dataType: String?  // "text" أو "image"
    var content: String?   // محتوى النص أو Base64 للصورة
}

// تحديث MessageDTO ليدعم المصادر
struct MessageDTO: Codable, Equatable, Identifiable {
    var id = UUID()
    var role: SenderRole
    var content: String
    var attachments: [Attachment] = []
    var timestamp: TimeInterval   // milliseconds منذ Epoch
    var grounding: GroundingMetadata? = nil // جديد: المصادر مع قيمة افتراضية
}

struct ChatDTO: Codable, Equatable, Identifiable {
    var id: String                // عادةً رقم الوقت كـ String
    var title: String
    var messages: [MessageDTO]
    var createdAt: TimeInterval
    var updatedAt: TimeInterval
    var order: Double             // للفرز نزولياً في القائمة
}

struct ZeusStore: Codable, Equatable {
    var chats: [String: ChatDTO]  // قاموس المحادثات بواسطة id
    var currentChatId: String?    // المفعّلة حالياً
}

struct GroundingSource: Codable, Identifiable, Equatable {
    let id = UUID()
    var title: String
    var url: String
    var description: String? // وصف الصفحة
    var domain: String { // دومين مستخرج من الـ URL
        guard let urlObject = URL(string: url),
              let host = urlObject.host else {
            return url
        }
        return host.hasPrefix("www.") ? String(host.dropFirst(4)) : host
    }
    
    enum CodingKeys: String, CodingKey {
        case title, url, description
    }
}

struct GroundingMetadata: Codable, Equatable {
    var searchQueries: [String] = []
    var sources: [GroundingSource] = []
    var hasGrounding: Bool { !sources.isEmpty }
}


// ملاحظة: إذا كان لديك امتداد String.clippedTitle(...) في ملف آخر (مثلاً Views),
// فلا تضِفّه مجدداً هنا لتجنّب "Invalid redeclaration".
