import SwiftUI
import WebKit
import AppTrackingTransparency

struct WebView: UIViewRepresentable {
        let url: URL
        
        func makeCoordinator() -> WebViewCoordinator {
                WebViewCoordinator(self)
            }
        
        func makeUIView(context: Context) -> WKWebView {
                let configuration = WKWebViewConfiguration()
                
                // 1. السماح بتخزين البيانات بشكل دائم للكوكيز
                configuration.websiteDataStore = WKWebsiteDataStore.default()
                
                // 2. السماح بالوصول للملفات المضمنة (IFrames)
                configuration.preferences.setValue(true, forKey: "allowFileAccessFromFileURLs")
                
                let webView = WKWebView(frame: .zero, configuration: configuration)
                webView.navigationDelegate = context.coordinator
                webView.uiDelegate = context.coordinator
                
                // 3. استخدام تعريف متصفح Mac كامل لتجاوز قيود الجوال
                webView.customUserAgent = "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Safari/605.1.15"
                
                return webView
            }
        
        func updateUIView(_ webView: WKWebView, context: Context) {
                let request = URLRequest(url: url)
                webView.load(request)
            }
}

// المنسق (Coordinator)
class WebViewCoordinator: NSObject, WKNavigationDelegate, WKUIDelegate {
        var parent: WebView
        init(_ parent: WebView) { self.parent = parent }
        
        func webView(_ webView: WKWebView, createWebViewWith configuration: WKWebViewConfiguration, for navigationAction: WKNavigationAction, windowFeatures: WKWindowFeatures) -> WKWebView? {
                if navigationAction.targetFrame == nil {
                        webView.load(navigationAction.request)
                    }
                return nil
            }
}

struct ContentView: View {
        var body: some View {
                WebView(url: URL(string: "https://aistudio.google.com/")!)
                    .edgesIgnoringSafeArea(.all)
                    .onAppear {
                            // طلب الإذن فور التشغيل
                            ATTrackingManager.requestTrackingAuthorization { _ in }
                        }
            }
}

